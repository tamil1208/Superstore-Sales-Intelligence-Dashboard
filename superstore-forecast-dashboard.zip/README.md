# Superstore Sales Forecasting Dashboard (Task 7)

An interactive Streamlit dashboard covering:

- **Page 1 — Sales Overview**: total sales by year, monthly trend, region/category filters
- **Page 2 — Forecast Explorer**: pick Category or Region, pick a 1/2/3-month horizon, see the
  XGBoost forecast (best model) plus MAE/RMSE
- **Page 3 — Anomaly Report**: anomaly chart + table of flagged months
- **Page 4 — Product Demand Segments**: cluster chart + sub-category → cluster table

The three forecasting models (SARIMA, Prophet, XGBoost), the anomaly detector, and the clustering
model are trained and evaluated in `notebook/sales_forecasting_analysis.ipynb`. Their outputs are
exported as small CSV/JSON files under `app/artifacts/` and `app/data/`, which the Streamlit app reads
directly — the deployed app does **not** retrain models on every load, so it only needs
`streamlit`, `pandas`, `numpy`, and `plotly` (no `statsmodels` / `prophet` / `xgboost` required at
deploy time — those are only needed to run the notebook).

## Project structure

```
app/
  streamlit_app.py        # the 4-page dashboard
  requirements.txt        # deploy-time dependencies only
  data/                    # cleaned + aggregated sales data
  artifacts/               # precomputed model outputs (forecasts, metrics, clusters, anomalies)
notebook/
  sales_forecasting_analysis.ipynb   # SARIMA / Prophet / XGBoost training + comparison table
data/
  clean.csv                # full cleaned raw dataset (for reference / notebook)
```

## Run locally

```bash
cd app
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Deploy to Streamlit Community Cloud (free)

1. **Push this folder to a GitHub repo** (e.g. `superstore-forecast-dashboard`), keeping the
   `app/` folder structure intact:
   ```bash
   git init
   git add .
   git commit -m "Superstore sales forecasting dashboard"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```
2. Go to **[share.streamlit.io](https://share.streamlit.io)** and sign in with GitHub.
3. Click **"New app"**, select your repo/branch, and set:
   - **Main file path:** `app/streamlit_app.py`
4. Click **Deploy**. Streamlit Cloud will install `app/requirements.txt` automatically and give you
   a live `*.streamlit.app` URL — that's the link to submit.

## Regenerating the artifacts

If you change the underlying data or modeling logic, rerun the notebook
(`notebook/sales_forecasting_analysis.ipynb`) top to bottom, or the equivalent `build_artifacts.py`
export script, then copy the refreshed files from `artifacts/`/`data/` into `app/artifacts/`/`app/data/`
before redeploying.

## Model comparison summary

| Model | MAE | RMSE | MAPE |
|---|---|---|---|
| SARIMA(0,1,1)(0,1,1)[12] | ~19,300 | ~20,206 | ~20.4% |
| Prophet | ~21,672 | ~22,618 | ~24.4% |
| **XGBoost (lag features)** | **~16,977** | ~20,558 | **~16.7%** |

**XGBoost is recommended for production** — lowest MAE and MAPE, RMSE essentially tied with SARIMA,
and it generalizes cleanly to per-Category / per-Region forecasting used in the Forecast Explorer page.
